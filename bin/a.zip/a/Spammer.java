package a;
import java.util.Random;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.OneShotBehaviour;
import jade.core.behaviours.SimpleBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.util.Logger;

public class Spammer extends Agent {
	private Logger logger = Logger.getMyLogger(getClass().getName());
	private int n;
	private int m;
	@Override
	protected void setup() {
		Object[] args = getArguments();
		if (args != null) {
					for(int i=0;i<args.length; i++){
				if(args[i].equals("-size"))
					m=Integer.parseInt((String) args[++i]);
				else if(args[i].equals("-amount"))
					n=Integer.parseInt((String) args[++i]);
				}
		}
		
		ServiceDescription sd = new ServiceDescription();
		sd.setType("Spammer");
		sd.setName("SpammerService");
		DFAgentDescription dfd = new DFAgentDescription();
		dfd.setName(getAID());
		dfd.addServices(sd);
		try {
			DFService.register(this, dfd);
		} catch (FIPAException e) {
			logger.log(Logger.SEVERE, "Agent " + getLocalName() + " - Cannot register with DF", e);
			doDelete();
		}
		addBehaviour(new SimpleBehaviour(this) {
			private boolean start = false;
			@Override
			public void action() {
				MessageTemplate mt = MessageTemplate.and(MessageTemplate.MatchSender(new AID("ExperimentMaster", AID.ISLOCALNAME)),
						MessageTemplate.MatchContent("start"));
				ACLMessage msg = myAgent.receive(mt);
				if (msg != null) {
					myAgent.addBehaviour(new SpammerBehaviour());
					start = true;
				} else {
					block();
				}
			}
			@Override
			public boolean done() {
				return start;
			}
		});
	}

	private class SpammerBehaviour extends OneShotBehaviour {
		private AID[] messageConsumers;

		@Override
		public void action() {
			ServiceDescription sd = new ServiceDescription();
			sd.setType("MessageConsumer");
			DFAgentDescription dfd = new DFAgentDescription();
			dfd.addServices(sd);
			try {
				DFAgentDescription[] result = DFService.search(myAgent, dfd);
				logger.log(Logger.INFO, result.length + " consumers found");
				messageConsumers = new AID[result.length];
				for (int i = 0; i < result.length; ++i) {
					messageConsumers[i] = result[i].getName();
				}
			} catch (FIPAException e) {
				logger.log(Logger.SEVERE, "no consumers", e);
			}
			String content = new String();
			Random r = new Random();
			for (int i = 0; i < m; i++) {
				content += (char)(r.nextInt(26) + 'a');
			}
			ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
			for (int i = 0; i < messageConsumers.length; ++i) {
				msg.addReceiver(messageConsumers[i]);
			}
			msg.setContent(content);
			msg.setLanguage("spam");
			for (int i = 0; i < n; i++) {
				myAgent.send(msg);
			}
		}
	}
}