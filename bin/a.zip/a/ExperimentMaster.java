package a;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import jade.core.behaviours.OneShotBehaviour;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.util.Logger;

public class ExperimentMaster extends Agent {

	private final Logger logger = Logger.getMyLogger(getClass().getName());
	private AID[] spammers;
	private int consumers;
	private long st;

	@Override
	protected void setup() {
		addBehaviour(new OneShotBehaviour(this) {
			@Override
			public void action() {
				ServiceDescription sd = new ServiceDescription();
				sd.setType("Spammer");
				DFAgentDescription dfd = new DFAgentDescription();
				dfd.addServices(sd);
				try {
					DFAgentDescription[] result = DFService.search(myAgent, dfd);
					System.out.println(result.length + " spammers found");
					spammers = new AID[result.length];
					for (int i = 0; i < result.length; ++i) {
						spammers[i] = result[i].getName();
					}
				} catch (FIPAException e) {
					logger.log(Logger.SEVERE, "no spammers", e);
				}
				sd = new ServiceDescription();
				sd.setType("MessageConsumer");
				dfd = new DFAgentDescription();
				dfd.addServices(sd);
				try {
					DFAgentDescription[] result = DFService.search(myAgent, dfd);
					consumers = result.length;
				} catch (FIPAException e) {
					logger.log(Logger.SEVERE, "No consumers", e);
				}
				ACLMessage startMsg = new ACLMessage(ACLMessage.REQUEST);
				for (int i = 0; i < spammers.length; ++i) {
					startMsg.addReceiver(spammers[i]);
				}
				startMsg.setContent("start");
				myAgent.send(startMsg);
				st = System.currentTimeMillis();
				addBehaviour(new ListenDoneMessagesBehaviour());
			}
		});
	}

	private class ListenDoneMessagesBehaviour extends Behaviour {

		private int done;

		public ListenDoneMessagesBehaviour() {
			super();
			done = 0;
		}

		@Override
		public void action() {
			MessageTemplate mt = MessageTemplate.and(MessageTemplate.MatchPerformative(ACLMessage.INFORM),
					MessageTemplate.MatchContent("done"));
			ACLMessage msg = myAgent.receive(mt);
			if (msg != null) {
				++done;
			} else {
				block();
			}
		}

		@Override
		public boolean done() {
			return done == consumers;
		}

		@Override
		public int onEnd() {
			System.out.println("Execution time: " + (System.currentTimeMillis() - st) + "ms");
			return 0;
		}
	}
}