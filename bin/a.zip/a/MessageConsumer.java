package a;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import jade.domain.DFService;
import jade.domain.FIPAException;
import jade.domain.FIPAAgentManagement.DFAgentDescription;
import jade.domain.FIPAAgentManagement.ServiceDescription;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.util.Logger;

public class MessageConsumer extends Agent {

	private final Logger logger = Logger.getMyLogger(getClass().getName());
	private boolean partb=false;
	private int n;
	private String name;
	private int spammers;

	@Override
	protected void setup() {
		Object[] args = getArguments();
		if (args != null) {
			for(int i=0;i<args.length; i++){
				if(args[i].equals("-spammer")){	
					partb=true;	
					name = (String) args[++i];}
				else if(args[i].equals("-amount")){
					n=Integer.parseInt((String) args[++i]);
				}
			}
		}
		ServiceDescription sd = new ServiceDescription();
		sd.setType("MessageConsumer");
		sd.setName("MessageConsumerService");
		DFAgentDescription dfd = new DFAgentDescription();
		dfd.setName(getAID());
		dfd.addServices(sd);
		try {
			DFService.register(this, dfd);
		} catch (FIPAException e) {
			logger.log(Logger.SEVERE, "Agent " + getLocalName() + " cant register df", e);
			doDelete();
		}
		sd = new ServiceDescription();
		sd.setType("Spammer");
		dfd = new DFAgentDescription();
		dfd.addServices(sd);
		try {
			DFAgentDescription[] result = DFService.search(this, dfd);
			spammers = result.length;
		} catch (FIPAException e) {
			logger.log(Logger.SEVERE, "No spammers", e);
		}
		addBehaviour(new MessageConsumingBehaviour());
	}

	private class MessageConsumingBehaviour extends Behaviour {

		private Map<String, Integer> received; 
		private Queue<ACLMessage> toRead;
		public MessageConsumingBehaviour() {
			super();
			this.received = new HashMap<>(spammers);
			this.toRead = new LinkedList<>();
		}

		@Override
		public void action() {
			MessageTemplate mt = MessageTemplate.and(MessageTemplate.MatchPerformative(ACLMessage.INFORM),
					MessageTemplate.MatchLanguage("spam"));
			ACLMessage msg = myAgent.receive(mt);
			if (msg != null) {
					if(partb){
							if(msg.getSender().getName().equals(name)){
								process(msg);					
							} else {
								toRead.add(msg);
							}
					}
					else{
						process(msg);
					}
			} 
			else if(partb && toRead.size() > 0) {
					msg = toRead.poll();
					process(msg);
			} 
			else {
					block();
			}
		}

		private void process(ACLMessage msg) {
			String sender = msg.getSender().getName();
			if (received.containsKey(sender)) {
				received.put(sender, received.get(sender) + 1);
			} else {
				received.put(sender, 1);
			}
		}

		@Override
		public boolean done() {
			if (received.size() != spammers) {
				return false;
			}
			for (int i : received.values()) {
				if (i != n) {
					return false;
				}
			}

			System.out.println("done");
			ACLMessage doneMsg = new ACLMessage(ACLMessage.INFORM);
			doneMsg.addReceiver(new AID("ExperimentMaster", AID.ISLOCALNAME));
			doneMsg.setContent("done");
			myAgent.send(doneMsg);
			return true;
		}
	}
}